import java.io.FileWriter;
import java.io.IOException;
import vn.edu.tdtu.ArrayHandler;
import vn.edu.tdtu.ArrayOutput;

public class Program {
    public static void main(String[] args) {
        // Khởi tạo hai mảng một chiều
        int[] a = { 3, 1, 4, 5, 9 };
        int[] b = { 8, 2, 7, 6, 0 };

        // In hai mảng ban đầu
        System.out.println("Mảng a:");
        ArrayOutput.print(a);

        System.out.println("Mảng b:");
        ArrayOutput.print(b);

        // Gộp hai mảng
        int[] c = ArrayHandler.merge(a, b);
        System.out.println("Mảng sau khi gộp:");
        ArrayOutput.print(c);

        // Sắp xếp mảng c
        ArrayHandler.sort(c);
        System.out.println("Mảng sau khi sắp xếp:");
        ArrayOutput.print(c);

        // Ghi nội dung mảng vào file output.txt
        try (FileWriter writer = new FileWriter("output.txt")) {
            for (int num : c) {
                writer.write(num + " ");
            }
            System.out.println("Ghi dữ liệu vào output.txt thành công!");
        } catch (IOException e) {
            System.out.println("Lỗi khi ghi file: " + e.getMessage());
        }
    }
}
