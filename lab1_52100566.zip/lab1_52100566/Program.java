public class Program {
    public static void main(String[] args) {
        // Kiểm tra số lượng tham số truyền vào
        if (args.length != 3) {
            System.out.println("Invalid expression");
            return;
        }

        try {
            // Lấy toán hạng và toán tử từ args
            double num1 = Double.parseDouble(args[0]);
            String operator = args[1];
            double num2 = Double.parseDouble(args[2]);

            // Xử lý các phép toán
            double result;
            switch (operator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "x": // Phép nhân (dùng 'x' thay vì '*')
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0) {
                        System.out.println("Error: Division by zero");
                        return;
                    }
                    result = num1 / num2;
                    break;
                case "^": // Phép lũy thừa
                    result = Math.pow(num1, num2);
                    break;
                default:
                    System.out.println("Unsupported operator");
                    return;
            }

            // In kết quả
            System.out.println(result);
        } catch (NumberFormatException e) {
            System.out.println("Invalid expression");
        }
    }
}
